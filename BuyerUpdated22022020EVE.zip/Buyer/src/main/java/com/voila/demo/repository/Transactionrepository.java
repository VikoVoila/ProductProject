package com.voila.demo.repository;

import org.springframework.data.jpa.repository.support.JpaRepositoryImplementation;

import com.voila.demo.model.Transactions;

public interface Transactionrepository extends JpaRepositoryImplementation<Transactions, Integer>{

}
