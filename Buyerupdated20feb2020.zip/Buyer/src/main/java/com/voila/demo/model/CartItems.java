package com.voila.demo.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="cart_items")
public class CartItems {
	@Id
	private int cartItemId;
	
}
