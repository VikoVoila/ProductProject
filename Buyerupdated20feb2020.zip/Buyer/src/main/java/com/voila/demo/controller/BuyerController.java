package com.voila.demo.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.voila.demo.model.BuyerInfo;
import com.voila.demo.model.service.BuyersInfoService;
import com.voila.demo.repository.BuyerRepository;

@RestController
public class BuyerController {
	
	/* private final BuyerRepository repository; */
	@Autowired
	private BuyersInfoService buyerservice;
	
	/*
	 * public BuyerController(BuyerRepository repository) { // TODO Auto-generated
	 * constructor stub this.repository = repository; }
	 */
	
	// url mappings
	/*
	 * @PostMapping("/buyersinfo") BuyerInfo newBuyerInfo(@RequestBody BuyerInfo
	 * newBuyerInfo) { return repository.save(newBuyerInfo); }
	 */
	// get all buyer
	@RequestMapping("/buyers")    
	public List<BuyerInfo> getAllUser()  
	{    
	return buyerservice.getAllBuyers();    
	} 
	
	// post method to insert new buyer details
	@PostMapping("/buyersinfo")
	public BuyerInfo newBuyerInfo(@RequestBody BuyerInfo newBuyerInfo) {
		BuyerInfo buyerInfo = buyerservice.addBuyer(newBuyerInfo);
		return buyerInfo;
	}
	
	// getById method
	@GetMapping("/buyersinfo/{id}")
	public BuyerInfo getBuyerInfo(@PathVariable(value="id") Integer buyerId) {
		Optional<BuyerInfo> showBuyer = buyerservice.getBuyer(buyerId);
		return showBuyer.get();
	}
	
	@RequestMapping("/buyer")
	public String sayHi() {
		return "Hi Buyer";
	}
}
