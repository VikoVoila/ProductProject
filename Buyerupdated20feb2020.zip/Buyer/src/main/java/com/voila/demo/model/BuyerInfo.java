package com.voila.demo.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Size;

/**
 * Date :Feb 18,2020
 * @author Vivek
 * @version 1.0
 *
 */

@Entity
 
public class BuyerInfo {
	
	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	
	@Column(name = "username")
	private String name;
	
	@Column(name = "password")
	private String password;
	
	@Column(name = "email_id")
	private String emailId;
	
	@Column(name = "mobile_number")
	/* @Size(min=0,max=10) */
	private String mobileNo;
	
	/*
	 * @Temporal(TemporalType.TIMESTAMP)
	 * 
	 * @Column(name = "created_at", nullable = false, updatable = false)
	 * 
	 * @CreatedDate private Date createdAt;
	 */
	
	@Column(name = "date")
	private String date;

	public BuyerInfo(String name, String password, String emailId, String mobileNo, String date) {
		super();
		this.name = name;
		this.password = password;
		this.emailId = emailId;
		this.mobileNo = mobileNo;
		this.date = date;
	}

	public BuyerInfo() {
		super();
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	@Override
	public String toString() {
		return "BuyerInfo [id=" + id + ", name=" + name + ", password=" + password + ", emailId=" + emailId
				+ ", mobileNo=" + mobileNo + ", date=" + date + "]";
	}
	
	

}
