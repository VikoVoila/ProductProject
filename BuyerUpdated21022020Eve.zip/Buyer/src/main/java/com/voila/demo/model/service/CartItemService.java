package com.voila.demo.model.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.voila.demo.model.CartItems;
import com.voila.demo.repository.CartItemRepository;

@Service
public class CartItemService {
	
	@Autowired
	private CartItemRepository cartItemRepository;
	
	/*
	 * @Autowired private BuyerRepository buyerRepository;
	 */

	public List<CartItems> getAllCartItems() {
		// TODO Auto-generated method stub
		List<CartItems> allCartItems = new ArrayList<CartItems>();
		cartItemRepository.findAll().forEach(allCartItems::add);
		/* cartItemRepository.findAll().forEach(allCartItems::add); */
		return allCartItems;
	}

	public CartItems addCartItem(CartItems newCartItems) {
		// TODO Auto-generated method stub
		System.out.println("In service");
		return cartItemRepository.save(newCartItems);
	}
	
	
}
