export class InfoModels
{
    firstName:string;
    lastName:string;
    age:number;
    email:string;
    phone:number;
    city:string;
    addr:string;
    //city:string;
    package:string;
    trainpref:string;
}