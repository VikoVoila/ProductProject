package com.voila.demo.model.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;

import com.voila.demo.model.BuyerInfo;
import com.voila.demo.repository.BuyerRepository;

@Service
public class BuyersInfoService {
	
	@Autowired
	private BuyerRepository buyerRepository;
	
	public List<BuyerInfo> getAllBuyers(){
		List<BuyerInfo> buyersRecord = new ArrayList<BuyerInfo>();
		buyerRepository.findAll().forEach(buyersRecord::add);    
		return buyersRecord;
	}
	
	// add new buyer details
	public BuyerInfo addBuyer(BuyerInfo buyer) {
		return buyerRepository.save(buyer);
		
	}
	
	/*
	 * public BuyerInfo getBuyerById(BuyerInfo buyer) { return
	 * buyerRepository.findAll(id); }
	 */
	// getById method
	public Optional<BuyerInfo> getBuyer(@PathVariable Integer buyerId) {
		return buyerRepository.findById(buyerId);
				/*.orElseThrow(()-> new BuyerInfoNotFoundException(id));*/
	}
	
	// Delete Buyer BL
	public void deleteBuyersInfo(Integer buyerId) {
		// TODO Auto-generated method stub
		buyerRepository.deleteById(buyerId);
	}
	
	// Update BuyersInfo BL
	public BuyerInfo saveOrUpdate(BuyerInfo buyerInfo, Integer id, String emailId, String date ) {
		// TODO Auto-generated method stub
		/* buyerRepository.save(buyerInfo); */
		Optional<BuyerInfo> buyer = buyerRepository.findById(id);
		buyerInfo.setEmailId(emailId);
		buyerInfo.setDate(date);
		return buyerRepository.save(buyerInfo);
		
		
		// here onward we have to complete
		
	}
	
}
