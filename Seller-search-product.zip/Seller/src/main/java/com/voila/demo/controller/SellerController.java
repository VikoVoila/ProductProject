package com.voila.demo.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.voila.demo.model.Seller;
import com.voila.demo.model.service.SellerService;



@RestController
public class SellerController {
	
	/* private final BuyerRepository repository; */
	@Autowired
	private SellerService sellerService;
	
	/*
	 * public BuyerController(BuyerRepository repository) { // TODO Auto-generated
	 * constructor stub this.repository = repository; }
	 */
	
	// url mappings
	/*
	 * @PostMapping("/buyersinfo") BuyerInfo newBuyerInfo(@RequestBody BuyerInfo
	 * newBuyerInfo) { return repository.save(newBuyerInfo); }
	 */
	// get all buyer
	@RequestMapping("/seller")    
	public List<Seller> getAllUser()  
	{    
	return sellerService.getAllBuyers();    
	} 
	
	// post method to insert new buyer details
	@PostMapping("/seller")
	public Seller newSellerInfo(@RequestBody Seller newSellerInfo) {
		Seller sellerInfo = sellerService.addSeller(newSellerInfo);
		return sellerInfo;
	}
	
	// getById method
	@GetMapping("/sellerinfo/{id}")
	public Seller getBuyerInfo(@PathVariable(value="id") Integer sellerId) {
		Optional<Seller> showSeller = sellerService.getSeller(sellerId);
		return showSeller.get();
	}
	
	// Delete Seller
	@DeleteMapping("/sellerinfo/{sellerId}")
	private void deleteSeller(@PathVariable("sellerId") Integer sellerId) {
		sellerService.deleteSeller(sellerId);
	}
	
	
	
	
	
	@RequestMapping("/sellerhi")
	public String sayHi() {
		return "Hi Seller";
	}
}
