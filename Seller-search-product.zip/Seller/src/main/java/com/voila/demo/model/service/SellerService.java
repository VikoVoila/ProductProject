package com.voila.demo.model.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;

import com.voila.demo.model.Seller;
import com.voila.demo.repository.SellerRepository;



@Service
public class SellerService {
	
	@Autowired
	private SellerRepository sellerRepository;
	
	public List<Seller> getAllBuyers(){
		List<Seller> sellerRecord = new ArrayList<Seller>();
		sellerRepository.findAll().forEach(sellerRecord::add);    
		return sellerRecord;
	}
	
	// add new buyer details
	public Seller addSeller(Seller seller) {
		return sellerRepository.save(seller);
		
	}
	
	/*
	 * public BuyerInfo getBuyerById(BuyerInfo buyer) { return
	 * buyerRepository.findAll(id); }
	 */
	// getById method
	public Optional<Seller> getSeller(@PathVariable Integer sellerId) {
		return sellerRepository.findById(sellerId);
				/*.orElseThrow(()-> new BuyerInfoNotFoundException(id));*/
	}
	
	// Delete Buyer BL
	public void deleteSeller(Integer sellerId) {
		// TODO Auto-generated method stub
		sellerRepository.deleteById(sellerId);
	}
	
	// Update BuyersInfo BL
	public Seller saveOrUpdate(Seller seller, Integer id, String emailId, Date date ) {
		// TODO Auto-generated method stub
		/* buyerRepository.save(buyerInfo); */
		Optional<Seller> buyer = sellerRepository.findById(id);
		seller.setEmailId(emailId);
		return sellerRepository.save(seller);
		
		
		// here onward we have to complete
		
	}
	
}
