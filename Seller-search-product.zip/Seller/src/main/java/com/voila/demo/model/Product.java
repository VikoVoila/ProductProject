package com.voila.demo.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="product")
public class Product {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer productId;
	
	@Column(name="product_name")
	private String productName;
	
	/* @Column(name="manufacturer") */
	@Column
	private String manufacturer;
	
	/* @Column(name="model") */
	@Column
	private String model;
	
//	
	@ManyToOne
	@JoinColumn(name = "seller_id")
	private Seller seller;
	
	private Integer quantity;
	
	@Column(name="product_price")
	private Float price;
	
	@Column(name="category_id")
	private Integer categoryId;
	
	@Column(name = "sub_category_id")
	private Integer subCategoryId;
	
	@Column(name="description")
	private String decription;

	

	public Product(String productName, String manufacturer, String model, Seller seller, Integer quantity, Float price,
			Integer categoryId, Integer subCategoryId, String decription) {
		super();
		this.productName = productName;
		this.manufacturer = manufacturer;
		this.model = model;
		this.seller = seller;
		this.quantity = quantity;
		this.price = price;
		this.categoryId = categoryId;
		this.subCategoryId = subCategoryId;
		this.decription = decription;
	}

	public Product() {
		super();
	}

	

	public Integer getProductId() {
		return productId;
	}

	public void setProductId(Integer productId) {
		this.productId = productId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getManufacturer() {
		return manufacturer;
	}

	public void setManufacturer(String manufacturer) {
		this.manufacturer = manufacturer;
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public Seller getSeller() {
		return seller;
	}

	public void setSeller(Seller seller) {
		this.seller = seller;
	}

	public Integer getQuantity() {
		return quantity;
	}

	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}

	public Float getPrice() {
		return price;
	}

	public void setPrice(Float price) {
		this.price = price;
	}

	public Integer getCategoryId() {
		return categoryId;
	}

	public void setCategoryId(Integer categoryId) {
		this.categoryId = categoryId;
	}

	public Integer getSubCategoryId() {
		return subCategoryId;
	}

	public void setSubCategoryId(Integer subCategoryId) {
		this.subCategoryId = subCategoryId;
	}

	public String getDecription() {
		return decription;
	}

	public void setDecription(String decription) {
		this.decription = decription;
	}

	@Override
	public String toString() {
		return "Product [productId=" + productId + ", productName=" + productName + ", manufacturer=" + manufacturer
				+ ", model=" + model + ", seller=" + seller + ", quantity=" + quantity + ", price=" + price
				+ ", categoryId=" + categoryId + ", subCategoryId=" + subCategoryId + ", decription=" + decription
				+ "]";
	}

	
	
	
}
