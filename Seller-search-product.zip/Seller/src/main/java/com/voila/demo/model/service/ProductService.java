package com.voila.demo.model.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.voila.demo.model.Product;
import com.voila.demo.model.Seller;
import com.voila.demo.repository.ProductRepository;
import com.voila.demo.repository.SellerRepository;

@Service
public class ProductService {

	@Autowired
	private ProductRepository productRepository;

	@Autowired
	private SellerRepository sellerRepository;
	/*
	 * @Autowired private BuyerRepository buyerRepository;
	 */


	public List<Product> getAllProducts() { // TODO Auto-generated method stub
		List<Product> allProducts = new ArrayList<Product>();
		productRepository.findAll().forEach(allProducts::add);
		return allProducts;
	}


	// add new product details
	public Product addProduct(Product newProduct, Integer sellerId) {
		System.out.println("hi");
		Optional<Seller> seller = sellerRepository.findById(sellerId);
		newProduct.setSeller(seller.get());
		return productRepository.save(newProduct);

	}


	public List<Product> getSearchProduct(Product newProduct) {

		return productRepository.findProduct(newProduct.getProductName()); }




	/*
	 * public Product addCartItem(Product newCartItems, Integer buyerId) { // TODO
	 * Auto-generated method stub System.out.println("In service");
	 * Optional<BuyerInfo> buyer = buyerRepository.findById(buyerId);
	 * newCartItems.setBuyer(buyer.get()); return
	 * cartItemRepository.save(newCartItems); }
	 */



	/*
	 * public List<CartItems> getCartItems(Integer buyerId) { // TODO Auto-generated
	 * method stub
	 * 
	 * return cartItemRepository.getCartItemByBuyerId(buyerId); }
	 */

}
