package Voila.ExceptionHandling;

/**
 * Hello world!
 *
 */
public class TryCatchExample2 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello Voila!" );
        try  
        {  
        int data=50/0; //may throw exception   
                         // if exception occurs, the remaining statement will not exceute  
        System.out.println("rest of the code");  
        }  
             // handling the exception   
        catch(ArithmeticException e)  
        {  
            System.out.println(e);  
        }  
    }
}

// OUTPUT -
/*
 * Hello Voila! java.lang.ArithmeticException: / by zero rest of the code
 */