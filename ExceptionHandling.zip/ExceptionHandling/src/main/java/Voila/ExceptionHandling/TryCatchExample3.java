package Voila.ExceptionHandling;

/**
 * Hello world!
 *
 */
public class TryCatchExample3 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello Voila!" );
        try  
        {  
        int data=50/0; //may throw exception   
        }  
            //handling the exception  
        catch(ArithmeticException e)  
        {  
            System.out.println(e);  
        }  
        System.out.println("rest of the code");
    }
}

//OUTPUT -
/*
* Hello Voila! java.lang.ArithmeticException: / by zero rest of the code
*/