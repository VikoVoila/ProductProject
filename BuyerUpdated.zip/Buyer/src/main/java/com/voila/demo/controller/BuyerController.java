package com.voila.demo.controller;

import java.util.Optional;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.voila.demo.model.BuyerInfo;
import com.voila.demo.repository.BuyerRepository;

@RestController
public class BuyerController {
	
	private final BuyerRepository repository;
	public BuyerController(BuyerRepository repository) {
		// TODO Auto-generated constructor stub
		this.repository = repository;
	}
	
	// url mappings
	
	@PostMapping("/buyersinfo")
	BuyerInfo newBuyerInfo(@RequestBody BuyerInfo newBuyerInfo) {
		return repository.save(newBuyerInfo);
	}
	
	@GetMapping("/buyersinfo/{id}")
	Optional<BuyerInfo> One(@PathVariable Integer id) {
		return repository.findById(id);
				/*.orElseThrow(()-> new BuyerInfoNotFoundException(id));*/
	}
	@RequestMapping("/buyer")
	public String sayHi() {
		return "Hi Buyer";
	}
}
