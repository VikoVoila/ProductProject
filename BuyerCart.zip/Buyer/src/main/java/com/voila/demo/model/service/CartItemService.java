package com.voila.demo.model.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;

import com.voila.demo.model.CartItems;
import com.voila.demo.repository.CartItemRepository;

@Service
public class CartItemService {
	
	@Autowired
	private CartItemRepository cartItemRepository;
	
	/*
	 * @Autowired private BuyerRepository buyerRepository;
	 */

	public List<CartItems> getAllCartItems() {
		// TODO Auto-generated method stub
		List<CartItems> allCartItems = new ArrayList<CartItems>();
		cartItemRepository.findAll().forEach(allCartItems::add);
		/* cartItemRepository.findAll().forEach(allCartItems::add); */
		return allCartItems;
	}

	public CartItems addCartItem(CartItems newCartItems) {
		// TODO Auto-generated method stub
		System.out.println("In service");
		return cartItemRepository.save(newCartItems);
	}

	public Optional<CartItems> getCartItems(@PathVariable Integer cartId) {
		// TODO Auto-generated method stub
		return cartItemRepository.findById(cartId);
	}

	public void deleteItem(int cartId) {
		// TODO Auto-generated method stub
		cartItemRepository.deleteById(cartId);
		
	}

	public void saveOrUpdate(CartItems cartItems, int itemId) {
		// TODO Auto-generated method stub
		cartItemRepository.save(cartItems);
		
	}
	
	
}
