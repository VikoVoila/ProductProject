package com.voila.demo.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="cart_items")
public class CartItems {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int cartItemId;
	
	private int itemId;
	
	private int quantity;
	
	@ManyToOne
	@JoinColumn(name = "buyer_id")
	private BuyerInfo buyer;
	
	

	public CartItems() {
		super();
	}

	public CartItems(int cartItemId, int itemId, int quantity, BuyerInfo buyer) {
		super();
		this.cartItemId = cartItemId;
		this.itemId = itemId;
		this.quantity = quantity;
		this.buyer = buyer;
	}

	public int getCartItemId() {
		return cartItemId;
	}

	public void setCartItemId(int cartItemId) {
		this.cartItemId = cartItemId;
	}

	public int getItemId() {
		return itemId;
	}

	public void setItemId(int itemId) {
		this.itemId = itemId;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public BuyerInfo getBuyer() {
		return buyer;
	}

	public void setBuyer(BuyerInfo buyer) {
		this.buyer = buyer;
	}

	@Override
	public String toString() {
		return "CartItems [cartItemId=" + cartItemId + ", itemId=" + itemId + ", quantity=" + quantity + ", buyer="
				+ buyer + "]";
	}
	
	
	
}
