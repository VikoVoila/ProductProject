import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-buyer-logout',
  templateUrl: './buyer-logout.component.html',
  styleUrls: ['./buyer-logout.component.css']
})
export class BuyerLogoutComponent implements OnInit {

  constructor(private route: Router) { }

  ngOnInit(): void {
    window.localStorage.removeItem('token');
    window.localStorage.removeItem('name');
    window.localStorage.removeItem('id');
    console.log('logged out !...');
    this.route.navigate(['home']);
    alert("logged out succesfully :)")
  }

}
