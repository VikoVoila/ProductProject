import { Component, OnInit } from '@angular/core';
import { BuyerLoginService } from '../service/buyer-login.service';

@Component({
  selector: 'app-menu',
  templateUrl: './menu.component.html',
  styleUrls: ['./menu.component.css']
})
export class MenuComponent implements OnInit {
  // isUserLogedIn: boolean = false;

  constructor( public buyerLoginService: BuyerLoginService) { }

  ngOnInit(): void {
    // this.isUserLogedIn = this.buyerLoginService.isUserLogedIn();  // this will cause refresh problem so we have to add directly service
  }

}
