import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ProductsModel } from '../models/products.model';
import { CartModel } from '../models/cart.model';

@Injectable({
  providedIn: 'root'
})
export class ProductService {

  constructor(private http: HttpClient) { }

  buyerId: string = window.localStorage.getItem('id');

  // private baseUrl = "http://localhost:8182";
  private baseUrl = "http://localhost:8989/mentorportal/sellerService"; // for 8182
  // private baseUrl1 = "http://localhost:8080";
  private baseUrl1 = "http://localhost:8989/mentorportal/buyerService";

  public showAllProducts():Observable<any> {
    return this.http.get(this.baseUrl+'/products');
  }

  public addToCart(cart: CartModel):Observable<any> {
    console.log(cart);
    return this.http.post(this.baseUrl1+`/buyer/addcartitems/${this.buyerId}`, cart);
    console.log(cart);
  }

  
}
