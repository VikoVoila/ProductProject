import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, Router } from '@angular/router';
import { BuyerLoginService } from './buyer-login.service';

@Injectable({
  providedIn: 'root'
})
export class RouteGaurdService implements CanActivate {

  constructor(private buyerLoginService: BuyerLoginService, private router:Router) { }

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
    // console.log("canActivate ")
    if (this.buyerLoginService.isUserLogedIn())
      return true;

      this.router.navigate(['userlogin'])
      // above is navigating to login if we r in logout condition and typing url 
    return false;
  }
}
