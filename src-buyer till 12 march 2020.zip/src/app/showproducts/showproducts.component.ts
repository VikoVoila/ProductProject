import { Component, OnInit } from '@angular/core';
import { ProductsModel } from '../models/products.model';
import { ProductService } from '../service/product.service';
import { Router } from '@angular/router';
import { CartModel } from '../models/cart.model';

@Component({
  selector: 'app-showproducts',
  templateUrl: './showproducts.component.html',
  styleUrls: ['./showproducts.component.css']
})
export class ShowproductsComponent implements OnInit {

  allProducts : ProductsModel[];
  product: ProductsModel=new ProductsModel();
  cart: CartModel ;

  constructor( private router: Router, private productService: ProductService ) { }

  ngOnInit(): void {
    this.Products();
  }

  Products(): void{
    this.productService.showAllProducts()
    .subscribe(allItem => this.allProducts = allItem);
  }

  addtoCart(product: ProductsModel) {
    this.cart = new CartModel();
    this.cart.quantity = 1;
    this.cart.itemId = product.productId;
    this.cart.price = product.price;
    console.log(this.cart);
    this.productService.addToCart(this.cart).subscribe(()=> alert("Added to Cart successfully."));
    // alert("Added to Cart successfully.");
  }

}
