import { ProductsModel } from './products.model';

export class CartModel {
    cartItemId:number;
    itemId: number;
    quantity: number;
    price: number;
    product: ProductsModel = new ProductsModel;
    //name:string;
    buyer:number;
}

export class CartCheckOut{
    itemId:number;
    quantity:number;
    price:number;
}